<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1');


$base_url = "https://7gv0oagg0c.execute-api.us-east-1.amazonaws.com/dev/";


$url = $base_url."get-org";
$ch = curl_init( $url );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
$data = curl_exec($ch);
curl_close($ch);
?>

<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>All Partners | Career Launch</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="./../assets/images/favicon.ico">

    <!-- Responsive Table css -->
    <link href="./../assets/libs/admin-resources/rwd-table/rwd-table.min.css" rel="stylesheet" type="text/css" />

    <!-- Bootstrap Css -->
    <link href="./../assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="./../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="./../assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <style>
    th {
        padding: 20px !important;
    }

    td {
        padding: 20px !important;
    }
    </style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200..1000;1,200..1000&display=swap"
        rel="stylesheet">
</head>

<body data-sidebar="dark">

    <!-- <body data-layout="horizontal" data-topbar="light"> -->

    <!-- Begin page -->
    <div id="layout-wrapper">

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="" style="width:90%;margin:auto">

            <div class="page-content">
                <div class="container-fluid align-content-center">
                    <!-- <button type="button" class="btn btn-primary" id="liveToastBtn">Show live toast</button> -->


                    <div class="row">
                        <div class="col-3"></div>
                        <div class="col-6 align-self-center">

                            <div id="copyalert">

                            </div>

                            <div class="card" style="border-radius:20px">
                                <div class="card-body">
                                    <h1 style="font-weight:600">All Partners</h1>
                                    <p class="card-title-desc">Click on the <b>View Dashboard</b> button besides
                                        partners name, you will the the NACE dashboard.</p>

                                    <table class="table table-hover p-5">
                                        <thead>
                                            <tr>
                                                <th scope="col" style="width:20px">#</th>
                                                <th style="text-align:center">University Name</th>
                                                <th style="text-align:center">Link</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                        // Decode JSON string to associative array
                                                $partners = json_decode($data, true);
                                                $i = 1;
                                                foreach ($partners as $key => $value) {
                                                    echo "<tr>
                                                <th scope='row'>".$i."</th>
                                                <td>" . $key . "</td>
                                                <td style='text-align:center'><a href='http://da.careerreadinessinventory.academy/workexp.php?organization=" . $value . "' target='_blank' class='btn btn-sm btn-dark'>View
                                                        Dashboard</a>
                                                        <div id='url".$i."' style='display:none'> http://da.careerreadinessinventory.academy/workexp.php?organization=" . $value . " </div>
                                                        <a href='#' onclick='copy(`url".$i."`,`" . $key . "`)' class='btn btn-sm btn-link' style='color:black;font-size:20px'>
                                                        <i class='ri-file-copy-line'></i>
                                                        </a>
                                                        </td>
                                            </tr>";
                                                    $i++;
                                                }
                                            ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div> <!-- end col -->
                    </div> <!-- end row -->

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->



        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <script>
                    document.write(new Date().getFullYear())
                    </script> © Appzia.
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesdesign
                    </div>
                </div>
            </div>
        </div>
    </footer> -->

    <script>
    function copy(elementId, uni) {

        var aux = document.createElement("input");

        aux.setAttribute("value", document.getElementById(elementId).innerHTML);

        document.body.appendChild(aux);

        aux.select();

        document.execCommand("copy");

        document.body.removeChild(aux);
        $('#copyalert').append(
            "<div class='alert alert-success alert-dismissible' role='alert' style='font-size:15px;font-weight:600;'> <div> " +
            uni +
            "'s Dashboard link is copied! </div> <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button> </div>"
        );
    }
    </script>


    <!-- JAVASCRIPT -->
    <script src="./../assets/libs/jquery/jquery.min.js"></script>
    <script src="./../assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./../assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="./../assets/libs/simplebar/simplebar.min.js"></script>
    <script src="./../assets/libs/node-waves/waves.min.js"></script>

    <!-- Responsive Table js -->
    <script src="./../assets/libs/admin-resources/rwd-table/rwd-table.min.js"></script>

    <!-- Init js -->
    <script src="./../assets/js/pages/table-responsive.init.js"></script>

    <script src="./../assets/js/app.js"></script>

</body>

</html>